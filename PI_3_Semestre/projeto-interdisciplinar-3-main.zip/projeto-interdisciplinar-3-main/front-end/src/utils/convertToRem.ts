function convertToRem(size: number) {
    return `${size / 16}rem`;
}

export default convertToRem;