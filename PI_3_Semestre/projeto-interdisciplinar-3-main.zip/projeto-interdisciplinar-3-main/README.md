# projeto-interdisciplinar-3
Projeto interdisciplinar do terceiro semestre de desenvolvimento de software multplataforma | Tema: indústria, inovação e infraestrutura  ⚙
