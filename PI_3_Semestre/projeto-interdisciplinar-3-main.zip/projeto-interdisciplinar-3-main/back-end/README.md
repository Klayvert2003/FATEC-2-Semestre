# How to start back-end

<center>
            <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original-wordmark.svg" width="150px" height="150px">
          
</center>

## In the project directory, you can run:
### `npm install --global yarn`
### `yarn dev`

## In your browser write

### `https://localhost:3000`