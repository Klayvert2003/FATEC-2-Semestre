export class Produto{

    nome!: string;
    valor!: number;
    imagem!: Blob;
    descricao!: string;

}